<?php $__env->startSection('content'); ?>



<div class="container pt-3">
  <div class="card">
    <?php echo Form::open(['action' => ['PostsController@update', $post->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        
          <div class="pt-3 pl-3 pb-3" style="background-color:#56b03f32"> 
            <h4>Bearbeite deinen deine Daten</h4>
           </div>
           <div class=" pl-3 pt-3 pr-3">
            <?php echo e(Form::text('title', $post->title, ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

          </div>
          <div class=" pl-3 pb-3 pt-3 pr-3">
            <?php echo e(Form::text('body', $post->body, ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Body Text'])); ?>

          </div>

          <div class="pt-3 pl-3 pb-3"style="background-color:#56b03f32">  
            <h4>Wähle Tag und Zeit an dem der Stream zu sehen sein soll</h4>
           </div>
      
     
       <fieldset id="tage">
          <div class="row pl-3" style="margin-right: 400px;margin-top:px">
         
            <div class="col">
              <?php if($post->monday==0): ?>
                <input type="checkbox" name="monday">
              <?php else: ?>
                <input type="checkbox" name="monday" checked> 
              <?php endif; ?>  
                <label for="sasquatch">Montag</label>
            </div>
              <div class="col-10">
                <?php if($post->friday==0): ?>
                <input type="checkbox" name="friday">
              <?php else: ?>
                <input type="checkbox" name="friday" checked> 
              <?php endif; ?>  
                <label for="sasquatch">Freitag</label>
              </div>
            </div>  
      
              <div class="row pl-3"style="margin-right: 400px;margin-top:px">
                <div class="col">
                  <?php if($post->tuesday==0): ?>
                  <input type="checkbox" name="tuesday">
                <?php else: ?>
                  <input type="checkbox" name="tuesday" checked> 
                <?php endif; ?>  
                <label for="sasquatch">Dienstag</label>
              </div>
      
      
              <div class="col-10">
                <?php if($post->saturday==0): ?>
                <input type="checkbox" name="saturday">
              <?php else: ?>
                <input type="checkbox" name="saturday" checked> 
              <?php endif; ?>  
                <label for="sasquatch">Samstag</label>
              </div>
            </div>
      
            <div class="row pl-3"style="margin-right: 400px">
              <div class="col">
                <?php if($post->wednesday==0): ?>
                <input type="checkbox" name="wednesday">
              <?php else: ?>
                <input type="checkbox" name="wednesday" checked> 
              <?php endif; ?>  
                <label for="sasquatch">Mittwoch</label>
              </div>
      
              <div class="col-10">
                <?php if($post->sunday==0): ?>
                <input type="checkbox" name="sunday">
              <?php else: ?>
                <input type="checkbox" name="sunday" checked> 
              <?php endif; ?>  
                <label for="sasquatch">Sonntag</label>
              </div>
            </div>
      
            <div class="row pl-3" style="margin-right: 300px">
              <div class="col">
                <?php if($post->thursday==0): ?>
                <input type="checkbox" name="thursday">
              <?php else: ?>
                <input type="checkbox" name="thursday" checked> 
              <?php endif; ?>  
                <label for="sasquatch">Donnerstag</label>
              </div>
          </div>  
        </fieldset>
      
      
              <div class="" style="">
                <div class="col">
              <?php if($post->immer==0): ?>
                  <input value="<?php echo e($post->immer); ?>" type="checkbox" id="checkme"  name="immer" onclick="checkboxme()">
              <?php else: ?>
              <input value="<?php echo e($post->immer); ?>" type="checkbox" id="checkme"  name="immer" onclick="checkboxme()" checked>
              <?php endif; ?>    
                  <label style="font-weight:bold" for="sasquatch">Jeden Tag</label>
                </div>
              </div>
            
      
            
           
      
              <?php
             // $timeto = str_replace(".", ":",$post->timeto);
              //$timefrom = str_replace(".", ":",$post->timefrom);
              
               ?>
            
         
          <!-- Time-->
          <div class="row pl-3"style="margin-bottom: 20px;margin-top: 20px">  
      
              
              <div class=""style="margin-left: 15px;margin-top: 5px; margin-right: 15px">
                <p>von</p>
              </div> 
      
              <input type="time" id="" name="timefrom" value="<?php echo e(old('timefrom', $post->timefrom)); ?>" style="height:30px"
              min="0" max="24">  
              
              <div class=""style="margin-left: 15px;margin-top: 2px; margin-right: 15px">
              <p>bis</p>
              </div>
                
             <input type="time" id="" name="timeto" value="<?php echo e(old('timeto', $post->timeto)); ?>" style="height:30px"
               min="0" max="24">
      
             <div class=""style="margin-left: 15px;margin-top:2px; margin-right: 15px">
                  <p>Uhr</p>
              </div> 
        </div>
      
        <div class="form-group " >
          <label class="pl-3" for="image">Bild</label>
          <input type="file" name="image">
        </div>
        
        <?php echo e(Form::hidden('_method','PUT')); ?>

        <div class="pl-3 pb-3">
        <?php echo e(Form::submit('Submit', ['class'=>'btn'])); ?>

      </div>
    <?php echo Form::close(); ?>

    </div>   
  </div> 

  <script>
window.onload = function () { 
    if ( "<?php echo $post->immer ?>" != "0"){
      var checkBox = document.getElementById("checkme");
    
        if (checkBox.checked == true){
        document.getElementById('tage').setAttribute('disabled','disabled');
      } else {
        document.getElementById('tage').removeAttribute('disabled');
      }
    }
}
    function checkboxme() { 
      var checkBox = document.getElementById("checkme");
    
        if (checkBox.checked == true){
        document.getElementById('tage').setAttribute('disabled','disabled');
      } else {
        document.getElementById('tage').removeAttribute('disabled');
      }
    }
    
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FamilyShare2\resources\views/posts/edit.blade.php ENDPATH**/ ?>