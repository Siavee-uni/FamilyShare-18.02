<?php $__env->startSection('content'); ?>









<?php $__env->startSection('content'); ?>
<!-- Grid row -->

<div class="container">
    <div class="card"style="margin-bottom: 70px;">
      <div class=""style="margin-bottom: 10px;margin-top: 10px;margin-left: 10px;">
      <h4>click <a href="/posts/create" class="btn btn-outline-primary btn-rounded btn-md ml-2 mr-2">here</a> to add a new camera</h4>
      <h4>to start the stream click on the play button</h4>
    </div>
  </div>
      <div class="row text-center">
  <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <!-- Grid column -->
        <div class="col-lg-4 col-md-12 mb-4">
            <h4>Stream: <?php echo e($post->title); ?></h4>
  <!--Modal: Name-->
          <div class="modal fade" id="modal-<?php echo e($post->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
  
  <!--Content-->
              <div class="modal-content modal-xl">
  
  <!--Body-->
                <div class="modal-body mb-0 p-0">
  
                    <div class="embed-responsive embed-responsive-16by9 z-depth-1-half">
                      <iframe class="embed-responsive-item" src="<?php echo e($post->body); ?>"
                      allowfullscreen></iframe>
                    </div>
  
                 </div>
  
  <!--Footer-->
  <div class="modal-footer justify-content-center">
  <h4 id="modal-<?php echo e($post->id); ?>" class="mr-4"><?php echo e($post->title); ?></h4>
  <button type="button" class="btn btn-outline-primary btn-rounded btn-md ml-4" data-dismiss="modal">Close</button>
  </div>
  
  </div>
  <!--/.Content-->
  
  </div>
  </div>
  <!--Modal: Name-->
  
  <a><img class="img-fluid z-depth-1" src="/png/videoplayer.jpg" alt="video"
  data-toggle="modal" data-target="#modal-<?php echo e($post->id); ?>"></a>
  
  </div>
  <!-- Grid column -->
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
  <div class=""style="margin-left: 14px">
     <h4> You have no posts at the moment. </h4>
    </div>
  <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FamilyShare2\resources\views/pages/simple.blade.php ENDPATH**/ ?>