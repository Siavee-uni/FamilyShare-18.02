<?php $__env->startSection('content'); ?>
<!-- Grid row -->

<div class="container pt-3">
    <div class="card"style="margin-bottom: 70px;">
      <div class="pt-3 pl-3 pb-3"style="">
      <h4>klick <a href="/posts/create" class="btn btn-outline-primary btn-rounded btn-md ml-2 mr-2">hier</a> um eine neue Kamera hinzuzufügen</h4>
      
      <h4>Um den Stream zu starten klicke auf eins der Videos</h4>
      </div>
    </div>
      <div class="row text-center">

  <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <!-- Grid column -->
        <div class="col-lg-4 col-md-12 mb-4"> <!-- mb = margin bottom-->
            <h4>Ort: <?php echo e($post->title); ?></h4>
            <?php if(empty($post->timefrom)): ?>
            <h4>keine Zeit festgelegt</h4>
            <?php else: ?> 
            <h4>Verfügbar von <?php echo e($post->timefrom); ?> bis <?php echo e($post->timeto); ?></h4>
            <?php endif; ?>
  <!--Modal: Name-->
          <?php
          $timenow = date('H.m')+1;  
          ?>
          <?php if($post->online === 1): ?>
                  <div class="modal fade" id="modal-<?php echo e($post->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document"><!-- modal-dialog ist für die größe zuständig/styling-->
                      <div class="modal-content">
                        <div class="modal-body mb-0 p-0" style="">
                            <div class="embed-responsive embed-responsive-16by9 z-depth-1-half">
                              <iframe class="embed-responsive-item" src="<?php echo e($post->body); ?>" allowfullscreen></iframe>
                            </div>
                          <div class="modal-footer justify-content-center">
                            <h4 id="modal-<?php echo e($post->id); ?>" class="mr-4"><?php echo e($post->title); ?></h4>
                            <button type="button" class="btn btn-outline-primary btn-rounded btn-md ml-4" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                     </div>
                    </div>
                   </div>
                   
                    <?php if($post->ort === 1): ?> 
                    <a><img style="width:100%" onclick="test()" id="<?php echo e($post->id); ?>"class="z-depth-1 img-thumbnail" src="/img/küche.jpg" alt="video"
                      data-toggle="modal" data-target="#modal-<?php echo e($post->id); ?>"></a>
                    <?php elseif($post->ort === 2): ?>  
                    <a><img style="width:100%" onclick="test()" id="<?php echo e($post->id); ?>"class="z-depth-1 img-thumbnail" src="/png/wohnzimmer.jpg" alt="video"
                      data-toggle="modal" data-target="#modal-<?php echo e($post->id); ?>"></a>
                    <?php elseif($post->ort === 3): ?>  
                    <a><img style="width:100%" onclick="test()" id="<?php echo e($post->id); ?>"class="z-depth-1 img-thumbnail" src="/png/schlafzimmer.jpg" alt="video"
                      data-toggle="modal" data-target="#modal-<?php echo e($post->id); ?>"></a>
                    <?php elseif($post->ort === 4): ?>  
                    <a><img style="width:100%" onclick="test()" id="<?php echo e($post->id); ?>"class="z-depth-1 img-thumbnail" src="/png/garten.jpg" alt="video"
                      data-toggle="modal" data-target="#modal-<?php echo e($post->id); ?>"></a>
                    <?php elseif($post->image ==="noimage.jpg"): ?>
                      <a><img onclick="test()" id="<?php echo e($post->id); ?>"class="z-depth-1 img-thumbnail" src="/png/videoplayer.jpg" alt="video"
                        data-toggle="modal" data-target="#modal-<?php echo e($post->id); ?>"></a>  
                    <?php else: ?>
                        <a><img style="width:100%" onclick="test()" id="<?php echo e($post->id); ?>"class="z-depth-1 img-thumbnail" src="./storage/uploads/<?php echo e($post->image); ?>" alt="video"
                        data-toggle="modal" data-target="#modal-<?php echo e($post->id); ?>"></a>
                    <?php endif; ?>
            <?php else: ?>   
                  <a><img onclick="test()" id="<?php echo e($post->id); ?>"class="z-depth-1 img-thumbnail" src="/png/videoplayer.jpg" alt="video"
                  data-toggle="modal" data-target="#modal-<?php echo e($post->id); ?>"></a>
           <?php endif; ?>
          
      <div class="row pt-2">
        <div class="col text-left">
          <div class="row">
            <h5 class="pl-3">Status:</h5>
            <?php if($post->online === 1): ?>
            <h5 class="pl-2">Online</h5> <img id="online" class="pl-2" style="height:15px" src="/png/online.png" alt="">
            <?php else: ?>
            <h5 class="pl-2">Offline</h5><img id="offline" class="pl-2" style="height:15px " src="/png/offline.png" alt=""> 
            <?php endif; ?>
          </div>
      </div>
        <div class="col text-right">
          <?php if($post->online === 0): ?>

              <?php echo Form::open(['action' => ['PostsController@anfrage', $post->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

              <button class="green button" style="height: 25px" type="submit">Stream freischalten</button>
              <input name="anfrage" value="1" style="visibility: hidden">
              <?php echo Form::close(); ?>

        
          <?php elseif($post->online === 0 && $post->anfrage === 1): ?>
             <button class="" style="height: 25px" type="submit" disabled><h5>anfrage versendet</h5></button>
          <?php else: ?>
          <?php endif; ?>
        </div>
      </div>
  </div>
 
 
  <!-- Grid column -->

  <?php
 
  $timenow = date('H.m')+1;
 
  $timefrom = $post->timefrom;
  $timeto = $post->timeto;
  
  
 
 
  ?>
  <script>
        
        
          
        function test() {
          var time = <?php echo $timenow ?>;
          var timefrom = <?php echo $timefrom ?>; 
          var timeto = <?php echo $timeto ?>; 
          var timedif = <?php echo $timeto ?> - <?php echo $timenow ?>;
          

          if (time >= timefrom && time <= timeto) {
              var close = function() {
                  $("#modal-<?php echo e($post->id); ?>").modal("hide");
              }
             setTimeout(close, timedif);
             // var linka = document.getElementById("<?php echo e($post->id); ?>");
             // linka.element.setAttribute("data-toggle");
             } 
             else 
             {
              document.getElementById("<?php echo e($post->id); ?>").removeAttribute("data-toggle");
              alert("Sichbar um " + "<?php echo $timefrom ?>" + " Uhr");
          }
        }
  </script>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
  <div class=""style="margin-left: 14px; background-color:rgba(43, 255, 6, 0.116)">
     <h4> Momentan hast du keine Videos</h4>
  </div>

  <?php endif; ?>
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FamilyShare2\resources\views/posts/index.blade.php ENDPATH**/ ?>